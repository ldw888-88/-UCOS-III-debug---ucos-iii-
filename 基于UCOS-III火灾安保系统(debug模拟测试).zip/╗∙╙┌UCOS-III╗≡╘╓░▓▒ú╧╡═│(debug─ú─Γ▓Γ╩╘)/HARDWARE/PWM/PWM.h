#ifndef __PWM_H__ 
#define __PWM_H__
#include "sys.h"
 
void TIM_ADC_DMA_Init(uint32_t ARR,uint32_t PSC);
int Get_Temprate(void);
uint16_t T_Get_Adc_Average(uint8_t ch,uint8_t times);
void Get_WaLe(float *Level_Value,uint8_t *Level_Value2);
void Get_MQ2Value(float *Value,float *ppm);

#endif
