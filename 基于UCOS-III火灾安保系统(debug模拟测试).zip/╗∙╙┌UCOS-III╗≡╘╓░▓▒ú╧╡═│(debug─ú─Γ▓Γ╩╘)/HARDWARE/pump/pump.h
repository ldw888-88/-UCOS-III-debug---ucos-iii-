#ifndef __PUMP_H__ 
#define __PUMP_H__
 
 void Relay_Init(void);
 void Relay_On(void);
 void Relay_Off(void);
 
#endif
