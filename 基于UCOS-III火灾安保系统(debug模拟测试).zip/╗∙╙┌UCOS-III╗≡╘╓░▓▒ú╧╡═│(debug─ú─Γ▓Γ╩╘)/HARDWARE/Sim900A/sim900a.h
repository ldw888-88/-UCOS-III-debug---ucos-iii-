#ifndef _SIM900A_H_
#define _SIM900A_H_


void sim900a_send_English_message(char *message,char *phonenumber);
void Fire_Waring(void);
void Person_Anom(void);
//void sim900a_send_Chinese_message(char *message,char *phonenumber);


#endif


