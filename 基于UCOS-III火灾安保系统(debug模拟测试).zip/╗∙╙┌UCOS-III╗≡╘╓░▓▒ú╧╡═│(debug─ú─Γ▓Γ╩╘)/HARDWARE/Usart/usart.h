#ifndef _USART_H_
#define _USART_H_

#include "stm32f10x.h"


void Usart1_Init(unsigned int baud);

void Usart2_Init(unsigned int baud);

void Usart3_Init(unsigned int baud);

void Hardware_Init(void);

void Usart_SendString(USART_TypeDef *USARTx, unsigned char *str, unsigned short len);

void Usart_SendString2( USART_TypeDef * pUSARTx, char *str);

void UsartPrintf(USART_TypeDef *USARTx, char *fmt,...);

void Usart_SendHalfWord( USART_TypeDef * pUSARTx, uint16_t ch);

void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch);

#endif
