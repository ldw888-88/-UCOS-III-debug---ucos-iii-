#ifndef __HC_SR501_H__
#define	__HC_SR501_H__
#include "stm32f10x.h"
		
void HC_SR501_Init(void);
//int PIR_GetStatus(void);
void HC_SR_Change(uint8_t BitValue);
	
#endif

