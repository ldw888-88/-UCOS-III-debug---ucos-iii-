#include "HC_SR501.h"
#include "stm32f10x_exti.h"
//#include "stm32f10x_gpio.h"
#include "LED.h"
#include "Delay.h"
/**
  * @brief  HC_SR501�����жϳ�ʼ��
  * @param  
  * @retval 
  */
void HC_SR501_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	GPIO_InitTypeDef GPIO_Initstructre;
	GPIO_Initstructre.GPIO_Pin   = GPIO_Pin_15;
    GPIO_Initstructre.GPIO_Mode  = GPIO_Mode_IPD;
	GPIO_Initstructre.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_Initstructre);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource15);
	
	EXTI_InitTypeDef EXTI_InitStructure;
	EXTI_InitStructure.EXTI_Line = EXTI_Line15;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;//��ռ���ȼ�
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		//��Ӧ���ȼ�
	NVIC_Init(&NVIC_InitStructure);
	
}

/**
  * @brief  �ı��ƽ�ź�
  * @param  BitValue������ĵ�ƽ�ź�
  * @retval 
  */
void HC_SR_Change(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_15,(BitAction)BitValue);
	
}

//int PIR_GetStatus(void) {
//    // ����HC_SR501���������ŵ�״̬��1Ϊ��⵽�����˶���0Ϊ�����˶�
//    return GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_15);
//}

/**
  * @brief  �жϷ�����
  * @param  
  * @retval 
  */
void EXTI15_10_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line15) ==SET)
	{
//		LED2 =0;
//		delay_us(500);
//		LED2 = 1;
//		delay_us(100);
		EXTI_ClearITPendingBit(EXTI_Line15);
	}
	
}

